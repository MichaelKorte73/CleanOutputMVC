<?php

namespace App;

use CHK\Core\App as CoreApp;
use App\Controller\ShortenerController;

class App extends CoreApp
{
    
}