(function (window, document) {
    'use strict';

    function initShortener() {
        // ← Code aus functions.js
    }

    App.onReady(initShortener);

})(window, document);