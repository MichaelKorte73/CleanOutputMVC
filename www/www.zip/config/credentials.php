<?php
/**
 * ⚠️ NIEMALS COMMITTEN
 * .gitignore hinzufügen!
 */

return [
    'db' => [
        'dsn'  => 'mysql:host=HOSTNAME;dbname=DBNAME;charset=utf8mb4',
        'user' => 'USER',
        'password' => 'PWF',
    ],

    // später:
    // 'redis' => [...]
    // 'mail'  => [...]
];